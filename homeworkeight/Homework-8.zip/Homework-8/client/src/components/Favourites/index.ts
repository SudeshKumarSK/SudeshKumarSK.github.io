import Favourites from "./Favourites";

export default Favourites;