import Venue from "./Venue";

export default Venue;