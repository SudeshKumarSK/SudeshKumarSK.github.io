import MapModal from "./MapModal";

export default MapModal;