const NavBar = () => {
  return (
    <div>NavBar</div>
  )
}

export default NavBar;