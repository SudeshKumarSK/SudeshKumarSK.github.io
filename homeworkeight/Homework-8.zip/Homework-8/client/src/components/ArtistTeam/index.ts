import ArtistTeam from "./ArtistTeam";

export default ArtistTeam;